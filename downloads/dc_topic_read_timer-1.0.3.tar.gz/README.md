# Read Before New Topic

A standalone Discourse theme component that requires recorded reading time before eligible users can create new topics. Replies, editing and private messages remain available.

Version: 1.0.3. Requires Discourse 2026.10.0-latest or newer.

## Installation

1. Download the release archive.
2. In Admin > Appearance > Themes & components, choose Components > Install > From your device and upload the archive.
3. Include the component on each theme where the restriction should apply.
4. Set `guidelines_topic_id` to the guidelines topic on your own forum and verify that eligible users can access it.

## Settings

| Setting | Default | Purpose |
| --- | --- | --- |
| enabled | true | Enable the component. |
| required_reading_minutes | 5 | Required lifetime reading time. Zero disables the reading gate. |
| maximum_restricted_trust_level | 0 | Restrict this trust level and lower levels. Staff are exempt. |
| guidelines_topic_id | 4 | Topic opened when a locked New Topic control is clicked. Configure for your forum. |

## Behaviour

Eligible users see a lock icon and an explanation of the reading requirement. Clicking the locked button opens the configured guidelines topic in the same tab. Once Discourse records sufficient reading time, the button unlocks automatically and uses the theme's native primary styling.

Reading time comes from Discourse's recorded `UserStat.time_read`, in seconds. The component does not implement a browser reading timer or change trust levels. A failed initial reading check keeps eligible users restricted until a later check succeeds.

Replies, editing, private messages and reply drafts remain available. Reply as new topic and opening new-topic drafts are restricted. Existing category permissions remain in force. Staff, higher trust levels, logged-out visitors and anonymous-mode accounts retain core behaviour.

The component includes English, British English, German, Dutch, French, Spanish, Portuguese, Brazilian Portuguese, Italian and Turkish user-facing strings.

## Scope and verification

This component restricts the browser interface. Direct API requests, modified clients and themes without the component can bypass it. Server-side enforcement requires separate support.

Before general use, verify locking and unlocking with a non-staff account, keyboard and touch behaviour, the configured guidelines topic, and the appearance on your installed theme. Repository CI for this release passed unit, lint, locale and Discourse QUnit acceptance checks. Component CSS still requires visual verification on the installed site.

## Licence

MIT. See LICENSE.
